<?php
  session_start();

  if(isset($_SESSION['user_id']))
  {
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">

    <title> Home </title>

    <!-- Bootstrap core CSS -->
    <link href="./css/bootstrap.min.css" rel="stylesheet">

    
    <!-- Custom styles for this template -->
    <link href="./css/signin.css" rel="stylesheet">

  </head>

  <body>

    <div class="container">
    <nav class="container">
      <a href="./logout.php"> Logout </a>
    </nav>

    <h2> Dashboard </h2>

    <section>

      <article>
        
      <table class="table table-bordered ">
        <tr>
          <th> Make</th>
          <th> Model </th>
          <th> Year </th>
          <th>Mileage </th>
        </tr>
		
        <?php
            include 'db_connect.php';
            $db_conn = new db_connection();
            $query = "Select * From cars";
            $result = $db_conn->runqry($query);
            while( $row = mysqli_fetch_assoc($result))
            {
              ?>
              <tr>
                <td>	
                 <?php 
                    echo $row['make'] ;  
                  ?>
                </td>

                <td>
                  <?php 
                    echo $row['model'] ;  
                  ?>
                </td>
                <td>
                  <?php 
                    echo $row['year'] ;  
                  ?>
                </td>
                <td>
			
                  <?php 
                    echo $row['Mileage'] ;
                  ?>
                </td>

                <td>
                  <a href="./edit.php?id=<?php echo $row['id']; ?>"> Edit </a>
                   | 
                   <a href="./edit.php?delete=<?php echo $row['id']; ?>"> Delete </a>
                </td>
              </tr>

              <?php
            } // end of while

        ?>

        


      </table>

      </article>
      <a href="./add.php">Add Product</a>
    </section>

    </div> <!-- /container -->
  </body>
</html>
  <?php
  }else{
	  header("location: login.php");
  }
  ?>