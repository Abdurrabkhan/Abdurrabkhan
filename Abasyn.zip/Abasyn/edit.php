<?php
if(isset($_GET["id"])){
	$ID=$_GET["id"];
}
if(isset($_GET["delete"])){
	$ID=$_GET["delete"];
	include 'db_connect.php';
            $db_conn122 = new db_connection();
            $query="DELETE FROM cars WHERE id='$ID'";
            $result = $db_conn122->runqry($query);
			if($result){
				header("location: ./home.php");
			}
}
if(isset($_POST["submit"])){
	$make=$_POST["make"];
	$model=$_POST["model"];
	$year=$_POST["year"];
	$mileage=$_POST["mileage"];
	if(is_numeric($year)&& is_numeric($mileage)){
			include 'db_connect.php';
            $db_conn12 = new db_connection();
            $query="UPDATE cars SET make='$make',model='$model',year='$year',mileage='$mileage' WHERE id='$ID'";
            $result = $db_conn12->runqry($query);
			if($result){
				header("location: ./home.php");
			}
	}else{
		echo"enter a valid value";
	}
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">

    <title> Edit</title>

    <!-- Bootstrap core CSS -->
    <link href="./css/bootstrap.min.css" rel="stylesheet">

    
    <!-- Custom styles for this template -->
    <link href="./css/signin.css" rel="stylesheet">

  </head>

  <body>

    <div class="container">
    <nav class="container">
     
    </nav>

    <h2>  </h2>
	<section>
      <article>
	  <?php
	  include 'db_connect.php';
			$db_conn1 = new db_connection();
            $query = "Select * From cars WHERE id='$ID'";
            $result = $db_conn1->runqry($query);
            while( $row = mysqli_fetch_assoc($result)){
				$make1=$row['make'];
				$model1=$row['model'];
				$year1=$row['year'];
				$mileage1=$row['Mileage'];
			}
	  ?>
      <form  method="POST" action="./edit.php?id=<?php echo"$ID"?>" class="container">
	  
      <tr>
	 <td> Make </td> 
        <input type="text" name="make" value="<?php echo"$make1"; ?>" class="form-control"> <br>
		<td>model</td>
		<input type="text" name="model" value="<?php echo"$model1"; ?>" class="form-control"><br>
		<td>year</td>
		
		<input type="text" name="year" value="<?php echo"$year1"; ?>" class="form-control"><br>
		<td>Mileage</td>
		
		<input type="text" name="mileage" value="<?php echo"$mileage1"; ?>" class="form-control"><br>
		</tr>
		<tr>
		<input type="submit" name="submit" value="button" class="btn btn-primary">
         </tr>
		 </form>
      
      </article>
      
    </section>

    </div> <!-- /container -->
  </body>
</html>

