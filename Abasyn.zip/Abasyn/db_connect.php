	
	<?php
	
	class db_connection
	{
		private $hostname;
		private $username;
		private $password;
		private $db_name;
		private $link;

		public function __construct()
		{
			$this->hostname = "localhost";
			$this->username = "root";
			$this->password = "";
			$this->db_name = "assign_02";
			$this->connect();

		} // end of constrcutor
		private function connect()
		{
			$this->link = new mysqli($this->hostname, $this->username, $this->password, $this->db_name);
		}
		public function runqry($qry)
		{
			$result= $this->link->query($qry);
			return $result;
		} // end of getData 
	} // end of class db_connection

?>